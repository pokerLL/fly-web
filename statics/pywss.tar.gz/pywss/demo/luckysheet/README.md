# luckysheet 在线协同编辑

1、安装依赖：`pip install pywss`

2、启动后端服务：`python app.py`

3、浏览器访问地址：[http://localhost:8080/static/luckysheet.html](http://localhost:8080/static/luckysheet.html)

4、打开多个浏览器端口，即可完成在线编辑
